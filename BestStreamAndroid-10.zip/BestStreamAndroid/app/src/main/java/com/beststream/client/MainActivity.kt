package com.beststream.client

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.beststream.client.data.model.ChannelItem
import com.beststream.client.data.repository.StalkerRepository
import com.beststream.client.ui.channels.ChannelListScreen
import com.beststream.client.ui.login.LoginScreen
import com.beststream.client.ui.player.PlayerScreen
import com.beststream.client.ui.theme.BestStreamTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BestStreamTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    BestStreamApp()
                }
            }
        }
    }
}

@Composable
fun BestStreamApp(viewModel: MainViewModel = viewModel()) {
    val uiState by viewModel.uiState

    when (val state = uiState) {
        is UiState.Login -> {
            LoginScreen(
                onLoginSuccess = { portal, mac -> viewModel.login(portal, mac) },
                isLoading = state.isLoading,
                errorMessage = state.error
            )
        }
        is UiState.Channels -> {
            ChannelListScreen(
                channels = state.channels,
                onChannelClick = { channel -> viewModel.playChannel(channel) },
                onLogout = { viewModel.logout() }
            )
        }
        is UiState.Player -> {
            PlayerScreen(
                streamUrl = state.streamUrl,
                title = state.title,
                onBack = { viewModel.backToChannels() }
            )
        }
        is UiState.LoadingPlay -> {
            // Petit écran de chargement pendant qu'on récupère le lien temporaire
            androidx.compose.foundation.layout.Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = androidx.compose.ui.Alignment.Center
            ) {
                androidx.compose.material3.CircularProgressIndicator()
            }
        }
    }
}

class MainViewModel : ViewModel() {
    private val repository = StalkerRepository()

    private val _uiState = mutableStateOf<UiState>(UiState.Login())
    val uiState: State<UiState> = _uiState

    private var channelsCache = listOf<ChannelItem>()
    private var currentPortal = ""
    private var currentMac = ""

    fun login(portalUrl: String, mac: String) {
        _uiState.value = UiState.Login(isLoading = true)
        currentPortal = portalUrl
        currentMac = mac

        viewModelScope.launch {
            val result = repository.login(portalUrl, mac)
            result.fold(
                onSuccess = {
                    val channelsResult = repository.getChannels(portalUrl, mac)
                    channelsResult.fold(
                        onSuccess = { list ->
                            channelsCache = list
                            _uiState.value = UiState.Channels(list)
                        },
                        onFailure = { e ->
                            _uiState.value = UiState.Login(error = e.message ?: "Erreur chargement chaînes")
                        }
                    )
                },
                onFailure = { e ->
                    _uiState.value = UiState.Login(error = e.message ?: "Échec de connexion")
                }
            )
        }
    }

    fun playChannel(channel: ChannelItem) {
        val originalCmd = channel.cmds?.firstOrNull()?.url
        if (originalCmd.isNullOrBlank()) return

        _uiState.value = UiState.LoadingPlay

        viewModelScope.launch {
            // On demande une URL temporaire jouable (comme STBEmu)
            val result = repository.getPlayableUrl(currentPortal, currentMac, originalCmd)

            result.fold(
                onSuccess = { playableUrl ->
                    _uiState.value = UiState.Player(
                        streamUrl = playableUrl,
                        title = channel.name
                    )
                },
                onFailure = {
                    // En dernier recours on essaie l'URL originale
                    _uiState.value = UiState.Player(
                        streamUrl = originalCmd,
                        title = channel.name
                    )
                }
            )
        }
    }

    fun backToChannels() {
        _uiState.value = UiState.Channels(channelsCache)
    }

    fun logout() {
        _uiState.value = UiState.Login()
        channelsCache = emptyList()
        currentPortal = ""
        currentMac = ""
    }
}

sealed class UiState {
    data class Login(val isLoading: Boolean = false, val error: String? = null) : UiState()
    data class Channels(val channels: List<ChannelItem>) : UiState()
    data class Player(val streamUrl: String, val title: String) : UiState()
    object LoadingPlay : UiState()
}
