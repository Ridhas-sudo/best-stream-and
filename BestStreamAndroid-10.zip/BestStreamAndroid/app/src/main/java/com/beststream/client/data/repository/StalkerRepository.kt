package com.beststream.client.data.repository

import com.beststream.client.data.api.ApiClient
import com.beststream.client.data.model.ChannelItem
import com.beststream.client.data.model.VodItem

class StalkerRepository {

    private val possiblePaths = listOf(
        "/c/server/load.php",
        "/stalker_portal/server/load.php",
        "/server/load.php"
    )

    private var workingLoadUrl: String? = null
    private var workingBase: String? = null

    suspend fun login(portalUrl: String, mac: String): Result<String> {
        val cleanUrl = smartCleanUrl(portalUrl)
        val cleanMac = cleanMac(mac)
        val base = extractBaseDomain(cleanUrl)

        ApiClient.currentMac = cleanMac
        ApiClient.currentToken = ""

        val tried = mutableListOf<String>()
        var lastError: String? = null

        for (path in possiblePaths) {
            val loadUrl = base.trimEnd('/') + path
            tried.add(loadUrl)

            try {
                val api = ApiClient.create("$base/")
                val response = api.handshake(url = loadUrl, mac = cleanMac)

                if (response.js?.token != null) {
                    ApiClient.currentToken = response.js.token
                    workingLoadUrl = loadUrl
                    workingBase = base
                    return Result.success(response.js.token)
                }

                if (response.text?.contains("Authorization", ignoreCase = true) == true ||
                    response.text?.contains("token", ignoreCase = true) == true) {
                    workingLoadUrl = loadUrl
                    workingBase = base
                    return Result.success("ok")
                }

                if (response.js?.error != null) {
                    return Result.failure(Exception(response.js.error))
                }

            } catch (e: Exception) {
                lastError = e.message
            }
        }

        return Result.failure(
            Exception("Connexion échouée\n\nMAC : $cleanMac\n\nChemins testés :\n${tried.joinToString("\n")}\n\nErreur : $lastError")
        )
    }

    suspend fun getChannels(portalUrl: String, mac: String): Result<List<ChannelItem>> {
        return try {
            val cleanMac = cleanMac(mac)
            val loadUrl = workingLoadUrl ?: (extractBaseDomain(smartCleanUrl(portalUrl)) + "/c/server/load.php")
            val base = workingBase ?: extractBaseDomain(smartCleanUrl(portalUrl))

            ApiClient.currentMac = cleanMac
            val api = ApiClient.create("$base/")
            val response = api.getAllChannels(url = loadUrl, mac = cleanMac)
            Result.success(response.js?.data ?: emptyList())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Récupère une URL temporaire jouable (comportement STBEmu)
     */
    suspend fun getPlayableUrl(portalUrl: String, mac: String, cmd: String): Result<String> {
        return try {
            val cleanMac = cleanMac(mac)
            val loadUrl = workingLoadUrl ?: (extractBaseDomain(smartCleanUrl(portalUrl)) + "/c/server/load.php")
            val base = workingBase ?: extractBaseDomain(smartCleanUrl(portalUrl))

            ApiClient.currentMac = cleanMac
            val api = ApiClient.create("$base/")

            val response = api.createLink(
                url = loadUrl,
                cmd = cmd,
                mac = cleanMac
            )

            var playable = response.js?.cmd

            if (!playable.isNullOrBlank()) {
                // Nettoyage classique des réponses Stalker
                playable = playable
                    .replace("ffmpeg ", "", ignoreCase = true)
                    .replace("ffrt ", "", ignoreCase = true)
                    .trim()

                // Parfois l'URL est relative
                if (playable.startsWith("/")) {
                    playable = base.trimEnd('/') + playable
                }

                if (playable.startsWith("http")) {
                    return Result.success(playable)
                }
            }

            // Fallback : on essaie l'URL originale nettoyée
            val fallback = cmd
                .replace("ffmpeg ", "", ignoreCase = true)
                .replace("ffrt ", "", ignoreCase = true)
                .trim()

            Result.success(fallback)
        } catch (e: Exception) {
            val fallback = cmd
                .replace("ffmpeg ", "", ignoreCase = true)
                .replace("ffrt ", "", ignoreCase = true)
                .trim()
            Result.success(fallback)
        }
    }

    suspend fun getVod(portalUrl: String, mac: String): Result<List<VodItem>> {
        return try {
            val cleanMac = cleanMac(mac)
            val loadUrl = workingLoadUrl ?: (extractBaseDomain(smartCleanUrl(portalUrl)) + "/c/server/load.php")
            val base = workingBase ?: extractBaseDomain(smartCleanUrl(portalUrl))

            ApiClient.currentMac = cleanMac
            val api = ApiClient.create("$base/")
            val response = api.getVodList(url = loadUrl, mac = cleanMac)
            Result.success(response.js?.data ?: emptyList())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun smartCleanUrl(raw: String): String {
        var url = raw.trim()
        if (url.startsWith("://")) url = "http$url"
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "http://$url"
        }
        return url.replace(" ", "")
    }

    private fun cleanMac(mac: String): String {
        val hex = mac.uppercase().replace(Regex("[^0-9A-F]"), "")
        if (hex.length != 12) return mac.trim()
        return hex.chunked(2).joinToString(":")
    }

    private fun extractBaseDomain(url: String): String {
        val regex = Regex("""(https?://[^/]+)""")
        return regex.find(url)?.value ?: url.trimEnd('/')
    }
}
