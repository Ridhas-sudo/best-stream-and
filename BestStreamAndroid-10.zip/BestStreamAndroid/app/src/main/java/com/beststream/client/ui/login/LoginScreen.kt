package com.beststream.client.ui.login

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun LoginScreen(
    onLoginSuccess: (portalUrl: String, mac: String) -> Unit,
    isLoading: Boolean = false,
    errorMessage: String? = null
) {
    var portalUrl by remember { mutableStateOf("") }
    var mac by remember { mutableStateOf("") }
    var pasteText by remember { mutableStateOf("") }

    val clipboardManager = LocalClipboardManager.current

    // Fonction intelligente d'extraction
    fun extractFromText(text: String) {
        val cleaned = text.trim()

        // 1. Extraire l'URL (http ou https)
        val urlRegex = Regex("""https?://[^\s<>"']+""", RegexOption.IGNORE_CASE)
        val urlMatch = urlRegex.find(cleaned)
        if (urlMatch != null) {
            portalUrl = urlMatch.value.trimEnd('/', ')', ']', '}', ',', ';')
        } else {
            // Essaie de trouver un domaine même sans http
            val domainRegex = Regex("""(?:^|\s)((?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?::\d+)?(?:/[^\s]*)?)""")
            val domainMatch = domainRegex.find(cleaned)
            if (domainMatch != null) {
                portalUrl = "http://" + domainMatch.groupValues[1].trimEnd('/', ')', ']', '}', ',', ';')
            }
        }

        // 2. Extraire la MAC (plusieurs formats possibles)
        val macRegex = Regex(
            """(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}|[0-9A-Fa-f]{12}""",
            RegexOption.IGNORE_CASE
        )
        val macMatch = macRegex.find(cleaned)
        if (macMatch != null) {
            var foundMac = macMatch.value.uppercase()
            // Formate si c'est 12 caractères collés
            if (foundMac.length == 12 && !foundMac.contains(":") && !foundMac.contains("-")) {
                foundMac = foundMac.chunked(2).joinToString(":")
            }
            mac = foundMac.replace("-", ":")
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Tv,
            contentDescription = null,
            modifier = Modifier.size(72.dp),
            tint = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Best Stream",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        Text(
            text = "Client Portail",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
        )

        Spacer(modifier = Modifier.height(28.dp))

        // === Zone de collage intelligent ===
        OutlinedTextField(
            value = pasteText,
            onValueChange = {
                pasteText = it
                if (it.length > 10) {
                    extractFromText(it)
                }
            },
            label = { Text("Coller ici n'importe quel texte") },
            placeholder = { Text("Colle un message contenant l'URL + MAC") },
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp),
            maxLines = 4,
            trailingIcon = {
                IconButton(onClick = {
                    val clip = clipboardManager.getText()?.text
                    if (!clip.isNullOrBlank()) {
                        pasteText = clip
                        extractFromText(clip)
                    }
                }) {
                    Icon(Icons.Default.ContentPaste, contentDescription = "Coller")
                }
            }
        )

        Text(
            text = "L'application extrait automatiquement l'URL et la MAC",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        // === Champs remplis automatiquement ===
        OutlinedTextField(
            value = portalUrl,
            onValueChange = { portalUrl = it },
            label = { Text("URL du Portail") },
            placeholder = { Text("http://exemple.com/c/") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = mac,
            onValueChange = { mac = it.uppercase() },
            label = { Text("Adresse MAC") },
            placeholder = { Text("00:1A:79:XX:XX:XX") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        if (errorMessage != null) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = errorMessage,
                color = MaterialTheme.colorScheme.error,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        Button(
            onClick = {
                if (portalUrl.isNotBlank() && mac.isNotBlank()) {
                    onLoginSuccess(portalUrl.trim(), mac.trim())
                }
            },
            enabled = !isLoading && portalUrl.isNotBlank() && mac.isNotBlank(),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = MaterialTheme.colorScheme.onPrimary,
                    strokeWidth = 2.dp
                )
            } else {
                Text("Se connecter", fontSize = 16.sp)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Compatible Stalker / Ministra\nUtilise uniquement ton propre contenu",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
            textAlign = TextAlign.Center
        )
    }
}
