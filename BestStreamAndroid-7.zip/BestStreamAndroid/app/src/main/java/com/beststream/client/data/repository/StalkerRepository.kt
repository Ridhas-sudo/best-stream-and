package com.beststream.client.data.repository

import com.beststream.client.data.api.ApiClient
import com.beststream.client.data.model.ChannelItem
import com.beststream.client.data.model.VodItem

class StalkerRepository {

    // Chemins les plus utilisés par STBEmu
    private val possiblePaths = listOf(
        "/c/server/load.php",
        "/stalker_portal/server/load.php",
        "/server/load.php",
        "/c/",
        "/stalker_portal/c/"
    )

    suspend fun login(portalUrl: String, mac: String): Result<String> {
        val cleanUrl = smartCleanUrl(portalUrl)
        val cleanMac = cleanMac(mac)
        val base = extractBaseDomain(cleanUrl)

        // On configure le MAC pour les cookies (comme STBEmu)
        ApiClient.currentMac = cleanMac
        ApiClient.currentToken = ""

        val tried = mutableListOf<String>()
        var lastError: String? = null

        for (path in possiblePaths) {
            val loadUrl = base.trimEnd('/') + path
            tried.add(loadUrl)

            try {
                val api = ApiClient.create("$base/")
                val response = api.handshake(url = loadUrl, mac = cleanMac)

                // Succès si on a un token
                if (response.js?.token != null) {
                    ApiClient.currentToken = response.js.token
                    return Result.success(response.js.token)
                }

                // Certains portails renvoient juste un message de succès
                if (response.text?.contains("Authorization", ignoreCase = true) == true ||
                    response.text?.contains("token", ignoreCase = true) == true) {
                    return Result.success("ok")
                }

                // Erreur métier du portail (MAC non trouvée, expirée, etc.)
                if (response.js?.error != null) {
                    return Result.failure(Exception(response.js.error))
                }

            } catch (e: Exception) {
                lastError = e.message
            }
        }

        return Result.failure(
            Exception(
                "Connexion échouée (comportement STBEmu)\n\n" +
                "MAC : $cleanMac\n\n" +
                "Chemins testés :\n${tried.joinToString("\n")}\n\n" +
                "Dernière erreur : $lastError"
            )
        )
    }

    suspend fun getChannels(portalUrl: String, mac: String): Result<List<ChannelItem>> {
        return try {
            val cleanUrl = smartCleanUrl(portalUrl)
            val cleanMac = cleanMac(mac)
            val base = extractBaseDomain(cleanUrl)
            val loadUrl = "$base/c/server/load.php"

            ApiClient.currentMac = cleanMac
            val api = ApiClient.create("$base/")
            val response = api.getAllChannels(url = loadUrl, mac = cleanMac)
            Result.success(response.js?.data ?: emptyList())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getVod(portalUrl: String, mac: String): Result<List<VodItem>> {
        return try {
            val cleanUrl = smartCleanUrl(portalUrl)
            val cleanMac = cleanMac(mac)
            val base = extractBaseDomain(cleanUrl)
            val loadUrl = "$base/c/server/load.php"

            ApiClient.currentMac = cleanMac
            val api = ApiClient.create("$base/")
            val response = api.getVodList(url = loadUrl, mac = cleanMac)
            Result.success(response.js?.data ?: emptyList())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun smartCleanUrl(raw: String): String {
        var url = raw.trim()
        if (url.startsWith("://")) url = "http$url"
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "http://$url"
        }
        return url.replace(" ", "")
    }

    private fun cleanMac(mac: String): String {
        val hex = mac.uppercase().replace(Regex("[^0-9A-F]"), "")
        if (hex.length != 12) return mac.trim()
        return hex.chunked(2).joinToString(":")
    }

    private fun extractBaseDomain(url: String): String {
        val regex = Regex("""(https?://[^/]+)""")
        return regex.find(url)?.value ?: url.trimEnd('/')
    }
}
