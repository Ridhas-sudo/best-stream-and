# Best Stream Client – Application Android

Client Android (téléphone + Android TV) compatible **Stalker Portal / Ministra** pour ton propre service de streaming.

## Fonctionnalités

- Saisie de l’URL du portail + adresse MAC
- Handshake avec ton backend Best Stream Panel
- Liste des chaînes live autorisées pour la MAC
- Lecteur HLS intégré (ExoPlayer / Media3)
- Compatible avec les flux de ton load-balancer

## Comment compiler l’APK sur GitHub

1. Crée un nouveau dépôt GitHub
2. Upload tout le contenu de ce dossier
3. Va dans l’onglet **Actions**
4. Lance le workflow **Build APK** (ou push sur `main`)
5. Télécharge l’artefact **BestStream-APK**

L’APK se trouve dans : `app/build/outputs/apk/debug/app-debug.apk`

## Utilisation

1. Ouvre l’application
2. Entre l’URL de ton portail : `https://ton-domaine.com/c/`
3. Entre la MAC que tu as créée dans le Panel Admin
4. Connecte-toi → tu vois tes chaînes
5. Clique sur une chaîne pour la lire

## Notes importantes

- Utilise uniquement **tes propres flux HLS** (pas de contenu pirate)
- Le backend Laravel doit être en ligne et accessible
- Pour le debug, l’application autorise le trafic HTTP (cleartext)

## Structure

```
app/src/main/java/com/beststream/client/
├── data/          → API Retrofit + Models + Repository
├── ui/            → Login / Liste chaînes / Player
└── MainActivity.kt
```
