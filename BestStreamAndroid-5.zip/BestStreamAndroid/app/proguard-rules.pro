# Keep Gson models
-keepclassmembers class com.beststream.client.data.model.** { *; }
-keep class com.beststream.client.data.model.** { *; }
