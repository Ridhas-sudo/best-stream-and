package com.beststream.client.data.model

import com.google.gson.annotations.SerializedName

data class HandshakeResponse(
    val js: HandshakeJs? = null,
    val text: String? = null
)

data class HandshakeJs(
    val token: String? = null,
    val random: String? = null,
    val error: String? = null
)

data class ChannelsResponse(
    val js: ChannelsJs? = null
)

data class ChannelsJs(
    val data: List<ChannelItem>? = null,
    @SerializedName("total_items") val totalItems: Int? = 0
)

data class ChannelItem(
    val id: Int = 0,
    val name: String = "",
    val number: Int = 0,
    val logo: String? = null,
    val cmds: List<ChannelCmd>? = null,
    @SerializedName("tv_genre_id") val tvGenreId: Int? = 1
)

data class ChannelCmd(
    val id: Int = 0,
    @SerializedName("ch_id") val chId: Int = 0,
    val url: String = ""
)

data class VodResponse(
    val js: VodJs? = null
)

data class VodJs(
    val data: List<VodItem>? = null,
    @SerializedName("total_items") val totalItems: Int? = 0
)

data class VodItem(
    val id: Int = 0,
    val name: String = "",
    @SerializedName("o_name") val originalName: String? = null,
    val cover: String? = null,
    val cmd: String = "",
    val category: String? = null
)
