package com.beststream.client.data.api

import com.beststream.client.data.model.ChannelsResponse
import com.beststream.client.data.model.HandshakeResponse
import com.beststream.client.data.model.VodResponse
import retrofit2.http.GET
import retrofit2.http.Query
import retrofit2.http.Url

interface StalkerApi {

    @GET
    suspend fun handshake(
        @Url url: String,
        @Query("type") type: String = "stb",
        @Query("action") action: String = "handshake",
        @Query("mac") mac: String,
        @Query("token") token: String = ""
    ): HandshakeResponse

    @GET
    suspend fun getAllChannels(
        @Url url: String,
        @Query("type") type: String = "itv",
        @Query("action") action: String = "get_all_channels",
        @Query("mac") mac: String
    ): ChannelsResponse

    @GET
    suspend fun getVodList(
        @Url url: String,
        @Query("type") type: String = "vod",
        @Query("action") action: String = "get_ordered_list",
        @Query("mac") mac: String
    ): VodResponse
}
