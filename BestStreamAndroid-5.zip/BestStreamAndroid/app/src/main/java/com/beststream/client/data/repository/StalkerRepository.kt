package com.beststream.client.data.repository

import com.beststream.client.data.api.ApiClient
import com.beststream.client.data.model.ChannelItem
import com.beststream.client.data.model.VodItem

class StalkerRepository {

    suspend fun login(portalUrl: String, mac: String): Result<String> {
        return try {
            val cleanMac = cleanMac(mac)
            val loadUrl = buildLoadUrl(portalUrl)

            val api = ApiClient.create(extractBaseUrl(portalUrl))
            val response = api.handshake(url = loadUrl, mac = cleanMac)

            when {
                response.js?.error != null -> {
                    Result.failure(Exception(response.js.error))
                }
                response.js?.token != null -> {
                    Result.success(response.js.token)
                }
                response.text?.contains("Authorization", ignoreCase = true) == true -> {
                    Result.success("ok")
                }
                else -> {
                    Result.failure(Exception("Réponse inattendue du serveur"))
                }
            }
        } catch (e: Exception) {
            val cleanMac = cleanMac(mac)
            val loadUrl = buildLoadUrl(portalUrl)
            Result.failure(
                Exception("HTTP Error\nURL appelée : $loadUrl\nMAC utilisée : $cleanMac\nDétail : ${e.message}")
            )
        }
    }

    suspend fun getChannels(portalUrl: String, mac: String): Result<List<ChannelItem>> {
        return try {
            val cleanMac = cleanMac(mac)
            val loadUrl = buildLoadUrl(portalUrl)
            val api = ApiClient.create(extractBaseUrl(portalUrl))
            val response = api.getAllChannels(url = loadUrl, mac = cleanMac)
            Result.success(response.js?.data ?: emptyList())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getVod(portalUrl: String, mac: String): Result<List<VodItem>> {
        return try {
            val cleanMac = cleanMac(mac)
            val loadUrl = buildLoadUrl(portalUrl)
            val api = ApiClient.create(extractBaseUrl(portalUrl))
            val response = api.getVodList(url = loadUrl, mac = cleanMac)
            Result.success(response.js?.data ?: emptyList())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Nettoie et normalise l'adresse MAC */
    private fun cleanMac(mac: String): String {
        val hex = mac.uppercase().replace(Regex("[^0-9A-F]"), "")
        if (hex.length != 12) return mac.trim()
        return hex.chunked(2).joinToString(":")
    }

    /**
     * Construit intelligemment l'URL vers load.php
     */
    private fun buildLoadUrl(rawUrl: String): String {
        var url = rawUrl.trim().trimEnd('/')

        if (url.endsWith("load.php", ignoreCase = true)) {
            return url
        }

        if (url.endsWith("/c", ignoreCase = true)) {
            return "$url/server/load.php"
        }

        if (url.contains("stalker_portal", ignoreCase = true)) {
            return if (url.endsWith("/server", ignoreCase = true)) {
                "$url/load.php"
            } else {
                "$url/server/load.php"
            }
        }

        return "$url/c/server/load.php"
    }

    private fun extractBaseUrl(rawUrl: String): String {
        val clean = rawUrl.trim().trimEnd('/')
        return "$clean/"
    }
}
