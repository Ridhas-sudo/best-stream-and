package com.beststream.client.data.repository

import com.beststream.client.data.api.ApiClient
import com.beststream.client.data.model.ChannelItem
import com.beststream.client.data.model.VodItem

class StalkerRepository {

    suspend fun login(portalUrl: String, mac: String): Result<String> {
        return try {
            val cleanUrl = smartCleanUrl(portalUrl)
            val cleanMac = cleanMac(mac)
            val loadUrl = buildLoadUrl(cleanUrl)

            val api = ApiClient.create(extractBaseUrl(cleanUrl))
            val response = api.handshake(url = loadUrl, mac = cleanMac)

            when {
                response.js?.error != null -> Result.failure(Exception(response.js.error))
                response.js?.token != null -> Result.success(response.js.token)
                response.text?.contains("Authorization", ignoreCase = true) == true -> Result.success("ok")
                else -> Result.failure(Exception("Réponse inattendue du serveur"))
            }
        } catch (e: Exception) {
            val cleanUrl = smartCleanUrl(portalUrl)
            val cleanMac = cleanMac(mac)
            val loadUrl = buildLoadUrl(cleanUrl)
            Result.failure(
                Exception("Erreur de connexion\n\nURL appelée :\n$loadUrl\n\nMAC : $cleanMac\n\nDétail : ${e.message}")
            )
        }
    }

    suspend fun getChannels(portalUrl: String, mac: String): Result<List<ChannelItem>> {
        return try {
            val cleanUrl = smartCleanUrl(portalUrl)
            val cleanMac = cleanMac(mac)
            val loadUrl = buildLoadUrl(cleanUrl)
            val api = ApiClient.create(extractBaseUrl(cleanUrl))
            val response = api.getAllChannels(url = loadUrl, mac = cleanMac)
            Result.success(response.js?.data ?: emptyList())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getVod(portalUrl: String, mac: String): Result<List<VodItem>> {
        return try {
            val cleanUrl = smartCleanUrl(portalUrl)
            val cleanMac = cleanMac(mac)
            val loadUrl = buildLoadUrl(cleanUrl)
            val api = ApiClient.create(extractBaseUrl(cleanUrl))
            val response = api.getVodList(url = loadUrl, mac = cleanMac)
            Result.success(response.js?.data ?: emptyList())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Nettoyage intelligent de l'URL
     * - Ajoute http:// si manquant
     * - Corrige ://domain → http://domain
     * - Enlève les espaces
     */
    private fun smartCleanUrl(raw: String): String {
        var url = raw.trim()

        // Cas ://domain.com  →  http://domain.com
        if (url.startsWith("://")) {
            url = "http$url"
        }

        // Cas domain.com  →  http://domain.com
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "http://$url"
        }

        // Enlève les espaces éventuels
        url = url.replace(" ", "")

        return url
    }

    /** Nettoie et normalise l'adresse MAC */
    private fun cleanMac(mac: String): String {
        val hex = mac.uppercase().replace(Regex("[^0-9A-F]"), "")
        if (hex.length != 12) return mac.trim()
        return hex.chunked(2).joinToString(":")
    }

    private fun buildLoadUrl(cleanUrl: String): String {
        var url = cleanUrl.trimEnd('/')

        if (url.endsWith("load.php", ignoreCase = true)) {
            return url
        }

        if (url.endsWith("/c", ignoreCase = true)) {
            return "$url/server/load.php"
        }

        if (url.contains("stalker_portal", ignoreCase = true)) {
            return if (url.endsWith("/server", ignoreCase = true)) {
                "$url/load.php"
            } else {
                "$url/server/load.php"
            }
        }

        return "$url/c/server/load.php"
    }

    private fun extractBaseUrl(cleanUrl: String): String {
        return cleanUrl.trimEnd('/') + "/"
    }
}
