package com.beststream.client.data.repository

import com.beststream.client.data.api.ApiClient
import com.beststream.client.data.model.ChannelItem
import com.beststream.client.data.model.VodItem

class StalkerRepository {

    suspend fun login(portalUrl: String, mac: String): Result<String> {
        return try {
            val loadUrl = buildLoadUrl(portalUrl)
            val api = ApiClient.create(extractBaseUrl(portalUrl))
            val response = api.handshake(url = loadUrl, mac = mac)

            if (response.js?.error != null) {
                Result.failure(Exception(response.js.error))
            } else if (response.js?.token != null) {
                Result.success(response.js.token)
            } else if (response.text != null && response.text.contains("Authorization", ignoreCase = true)) {
                // Some portals return success without token in js
                Result.success("ok")
            } else {
                Result.failure(Exception("Handshake failed: ${response.text ?: "Empty response"}"))
            }
        } catch (e: Exception) {
            Result.failure(Exception("${e.message}\nURL appelée: ${buildLoadUrl(portalUrl)}"))
        }
    }

    suspend fun getChannels(portalUrl: String, mac: String): Result<List<ChannelItem>> {
        return try {
            val loadUrl = buildLoadUrl(portalUrl)
            val api = ApiClient.create(extractBaseUrl(portalUrl))
            val response = api.getAllChannels(url = loadUrl, mac = mac)
            Result.success(response.js?.data ?: emptyList())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getVod(portalUrl: String, mac: String): Result<List<VodItem>> {
        return try {
            val loadUrl = buildLoadUrl(portalUrl)
            val api = ApiClient.create(extractBaseUrl(portalUrl))
            val response = api.getVodList(url = loadUrl, mac = mac)
            Result.success(response.js?.data ?: emptyList())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Construit l'URL complète vers load.php
     * Exemple d'entrée : http://line.atlaspro4k.me/c/
     * Résultat attendu : http://line.atlaspro4k.me/c/server/load.php
     */
    private fun buildLoadUrl(portalUrl: String): String {
        var url = portalUrl.trim().trimEnd('/')

        // Cas déjà complet
        if (url.endsWith("load.php")) {
            return url
        }

        // Cas classique Stalker : .../c  ou  .../c/
        if (url.endsWith("/c")) {
            return "$url/server/load.php"
        }

        // Cas stalker_portal
        if (url.contains("stalker_portal")) {
            return if (url.endsWith("server")) {
                "$url/load.php"
            } else {
                "$url/server/load.php"
            }
        }

        // Par défaut on ajoute /c/server/load.php
        return "$url/c/server/load.php"
    }

    private fun extractBaseUrl(portalUrl: String): String {
        // Retrofit a besoin d'une base URL se terminant par /
        val clean = portalUrl.trim().trimEnd('/')
        return "$clean/"
    }
}
