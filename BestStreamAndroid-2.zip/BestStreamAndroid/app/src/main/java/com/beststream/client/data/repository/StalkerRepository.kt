package com.beststream.client.data.repository

import com.beststream.client.data.api.ApiClient
import com.beststream.client.data.model.ChannelItem
import com.beststream.client.data.model.VodItem

class StalkerRepository {

    suspend fun login(portalUrl: String, mac: String): Result<String> {
        return try {
            val api = ApiClient.create(portalUrl)
            // The load.php endpoint
            val loadUrl = buildLoadUrl(portalUrl)
            val response = api.handshake(url = loadUrl, mac = mac)

            if (response.js?.error != null) {
                Result.failure(Exception(response.js.error))
            } else if (response.js?.token != null) {
                Result.success(response.js.token)
            } else {
                Result.failure(Exception("Handshake failed: ${response.text ?: "Unknown error"}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getChannels(portalUrl: String, mac: String): Result<List<ChannelItem>> {
        return try {
            val api = ApiClient.create(portalUrl)
            val loadUrl = buildLoadUrl(portalUrl)
            val response = api.getAllChannels(url = loadUrl, mac = mac)
            Result.success(response.js?.data ?: emptyList())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getVod(portalUrl: String, mac: String): Result<List<VodItem>> {
        return try {
            val api = ApiClient.create(portalUrl)
            val loadUrl = buildLoadUrl(portalUrl)
            val response = api.getVodList(url = loadUrl, mac = mac)
            Result.success(response.js?.data ?: emptyList())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun buildLoadUrl(portalUrl: String): String {
        val base = portalUrl.trimEnd('/')
        // Support both /c/ and /stalker_portal/server/load.php styles
        return when {
            base.endsWith("/c") || base.endsWith("/c/") -> "$base/server/load.php"
            base.contains("stalker_portal") -> "$base/server/load.php"
            else -> "$base/c/server/load.php"
        }
    }
}
